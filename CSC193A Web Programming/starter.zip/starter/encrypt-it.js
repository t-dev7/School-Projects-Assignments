/*
 * Starter file 
 */

console.log("Window loaded!");

(function() {
  "use strict";

  /**
   * The starting point in our program, setting up a listener
   * for the "load" event on the window, signalling the HTML DOM has been constructed
   * on the page. When this event occurs, the attached function (init) will be called.
   */
  window.addEventListener("load", init);
 
  /**
   * TODO: Write a function comment using JSDoc.
   */
  function init() {
    // Note: In this function, we usually want to set up our event handlers
    // for UI elements on the page.
    document.getElementById("encrypt-it").addEventListener("click", handleEncrypt);
    document.getElementById("reset").addEventListener("click", handleReset);
  }


  // Add any other functions in this area (you should not implement your
  // entire program in the init function, for similar reasons that
  // you shouldn't write an entire Java program in the main method).

  function handleEncrypt(){
    console.log("Button Clicked!");
    let string = document.getElementById("input-text").value;
    string = string.toLowerCase();

    let result = '';

    for(let i = 0; i < string.length; i++){
      if(string[i] == String.fromCharCode(32)){
        result += String.fromCharCode(32);
      }
      
      // if char is lowercase z
      else if (string[i] == 'z'){
       result = result + String.fromCharCode(string[i].charCodeAt(string[i]) - 25);
      }
      //letters a -> y
      else{
        result += String.fromCharCode(string[i].charCodeAt(string[i]) + 1);
      }
    }
    document.getElementById("result").innerHTML = result;
  }

//Add an event handler to the "Reset" button such that when clicked a new handleReset function is called
  function handleReset(){
    //Update the function to clear out the inner HTML of the input-text
    document.getElementById("input-text").value = "";
    document.getElementById("result").innerHTML = "";
  }
})();
