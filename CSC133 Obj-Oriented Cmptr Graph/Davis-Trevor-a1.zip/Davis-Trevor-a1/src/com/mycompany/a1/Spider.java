package com.mycompany.a1;
import java.util.Random;
import java.lang.Math;

import com.codename1.charts.models.Point;
import com.codename1.charts.util.ColorUtil;

public class Spider extends Moveable{
	Random rand = new Random();
	Point location;
	
	public Spider(int size, Point location, int color, double heading) {
		//    size, location, color, heading, speed
		super(size, location, color, heading, 5 );
	}
	
	public void move(Point oldLocation, double heading, int speed) {
		float deltaX;
		float deltaY ;
		float oldX;
		float oldY;
		deltaX = (float) (Math.cos(90-Math.toRadians(heading))*speed);
		deltaY = (float) (Math.sin(90-Math.toRadians(heading))*speed);
		
		oldX = oldLocation.getX();
		oldY = oldLocation.getY();
		
		 location.setX(deltaX + oldX);
		 location.setY(deltaY + oldY);
		
		
	super.move(location);
	}

	// empty method
	public void setLocation(Point location) {
		 
	 }

	// empty method
		public void setHeading(double heading) {
			
		}
		
		public String toString() {
			String colorDesc = "color=[" + ColorUtil.red(super.getColor())  + ", "
					 + ColorUtil.green(super.getColor()) + ", "
					 + ColorUtil.blue(super.getColor()) + "] ";

			String sLocation = "loc=" + super.getLocation().getX() + ", "
				  + super.getLocation().getY() + " ";

			String sSize = "size=" + super.getSize() + " ";
			
			String sHeading = "heading=" + super.getHeading();
			
			String sSpeed = "speed=" + super.getSpeed();
			
			return "Spider: " + sLocation + colorDesc + sHeading + sSpeed + sSize;
		}
}
