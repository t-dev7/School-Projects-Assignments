package com.mycompany.a1;
import com.codename1.charts.models.Point;
import com.codename1.charts.util.ColorUtil;

public abstract class Fixed extends GameObject{
	
	public Fixed(int size, Point location, int color) {
		super(size, location, color);
	}
	
// empty method because fixed game objects are not allowed to change location once created
// public void setLocation() { }

 public void setColor(int color) {
	 super.setColor(color);
 }


}