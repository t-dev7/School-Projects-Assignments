package com.mycompany.a1;
import com.codename1.charts.models.Point;
import java.util.Random;

public abstract class GameObject {
	private int size;
	private Point location;
	private int color;
	Random random;
	
	// default size of game objects ( might be changed later) 
	public GameObject(int size) {
		this.size = size;
		location = new Point(random.nextInt(40),random.nextInt(40));
		
		
	}

	// constructor for the size of the object
	public GameObject(int size, Point location, int color) {
		this.size = size;
		this.location = location;
		this.color = color;	
	}
	
	// method to get color (all objects able to get color)
	public int getColor() {
		return color;
	}
	
	// method to get Point (all objects able to get Location)
	public Point getLocation() {
		return location;
	}
	
	
	// method to set location from the subclasses
	 public void setLocation(Point location) {
		 this.location = location;
	 }
	 
	 public int getSize() {
			return size;
		}

	// method to set color from the subclasses
	public void setColor(int color) {
		this.color = color;
	}
	
}
