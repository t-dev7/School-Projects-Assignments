package com.mycompany.a1;
import com.codename1.charts.models.Point;
import com.codename1.charts.util.ColorUtil;

public class Flag extends Fixed{
	private int sequenceNumber;
	
	public Flag(int sNumber, Point location, int color) {
	 // super(size, location, color)
		super(10, location, color); 
		
		// sequence is set when there is new object
		sequenceNumber = sNumber; 
	}

public String toString() {
		String colorDesc = "color=[" + ColorUtil.red(super.getColor())  + ", "
									 + ColorUtil.green(super.getColor()) + ", "
									 + ColorUtil.blue(super.getColor()) + "] ";
		
		String sLocation = "loc=" + super.getLocation().getX() + ", "
								  + super.getLocation().getY() + " ";
		
		String sSize = "size=" + super.getSize() + " ";
		
		String sSeqNum = "seqNum=" + sequenceNumber;
		
		return "Flag: " + sLocation + colorDesc + sSize + sSeqNum;
	}
	
}
