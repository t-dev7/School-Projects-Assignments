package com.mycompany.a1;
import java.util.Random;
import com.codename1.charts.models.Point;
import com.codename1.charts.util.ColorUtil;

public class FoodStation extends Fixed{
	Random rand;
	private int capacity;
	
	// 
	public FoodStation (int size, Point location, int color, int capacity) {
	//  super(size, location, color)
		super(size, location, color);
		this.capacity = capacity;
		
	}
	
	public int getCapacity() {
		return capacity;
	}
	
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
	
public void setColor(int color) {
		
		super.setColor(color);
	}
	
	
public String toString() {
	String colorDesc = "color=[" + ColorUtil.red(super.getColor())  + ", "
								 + ColorUtil.green(super.getColor()) + ", "
								 + ColorUtil.blue(super.getColor()) + "] ";
	
	String sLocation = "loc=" + super.getLocation().getX() + ", "
							  + super.getLocation().getY() + " ";
	
	String sSize = "size=" + super.getSize() + " ";
	
	String sSeqNum = "seqNum=" + capacity;
	
	return "FoodStation: " + sLocation + colorDesc + sSize + sSeqNum;
}

}
