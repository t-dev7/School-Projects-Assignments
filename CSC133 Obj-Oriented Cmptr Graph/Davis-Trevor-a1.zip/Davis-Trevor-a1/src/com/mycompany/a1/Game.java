package com.mycompany.a1;
import com.codename1.ui.Form;
import com.codename1.ui.events.ActionListener;
import com.codename1.ui.Label;
import com.codename1.ui.TextField;
import com.codename1.ui.events.ActionEvent;
import java.lang.String;

public class Game extends Form{
	private GameWorld gw;
	
	public Game () {
		gw = new GameWorld(); // Game constructor instantiates a GameWorld
		gw.init(); // calls a GameWorld method init() to set the initial state of the game
		play(); // starts the game by calling a Game method play()
	}
	
	// Private "play" method...
	// accepts keyboard commands from the player and invokes appropriate 
	// methods in GameWorld to manipulate and display the data and game 
	// state values in the game model.
	private void play() { 	
		// system.in is not supported in CN1. 
		// We use a text field located on the form to enter the keyboard commands
		 
		Label myLabel=new Label("Enter a Command:");
		this.addComponent(myLabel);
		final TextField myTextField=new TextField();
		this.addComponent(myTextField);
		this.show();
		final boolean xTrue = false;
		
		myTextField.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent evt) {
				 
				String sCommand=myTextField.getText().toString();
				myTextField.clear();
				if(sCommand.length() != 0)
					if (gw.getxTrue() == false) { // if 'x' is not pressed
					switch (sCommand.charAt(0)) {
						case 'a': // tell game world to accelerate the ant by small amount
							gw.accelerate();
							break;
						case 'b': // tell game world to brake the ant by small amount
								gw.brake();
								break;
						case 'l': // ("ell") tell game world to change heading of ant left
								gw.left();
								break;
						case 'r': // tell game world to change heading of ant right
								gw.right();
								break;
						case 'f': // PRETEND ant collided with a food station
								gw.foodCollide();
								break;
						case 'g': // PRETEND spider has collided with the ant
								gw.spiderGotAnt();
								break;
						case 't': // tell the game world the 'game clock' has ticked
								gw.ticked();
								break;
						case 'd': // generate a display by outputting lines to text on console
								gw.displayState();
								break;
						case 'm': // tell game world to output a "map" showing current world
								gw.map();
								break;
								
						case '1': case '2': case '3': case '4': case '5': case '6':
						case '7': case '8': case '9':
							System.out.println(sCommand.charAt(0) + " was pressed");
							// chatAt() is unicode so we must subtract '0' to get true integer
							gw.flagReached(sCommand.charAt(0)-'0');  
							
								break;
													
								
						case 'x': // calls the method System.exit(0) to terminate program
							
							System.out.println("Would you like to termiate the program?");
							System.out.println("Please enter y for yes or n for no");
							gw.exit(); // method to flag that the last command was 'x'
								break;
								
						default:
							System.out.println("Please enter an acceptable input");
							break;
								
					
						
					}	// switch	
			} //if
					else if (gw.getxTrue() == true)		// if 'x' was the last key pressed
						switch (sCommand.charAt(0)) {
							case 'y':	// the user wants to terminate the program
								System.exit(0);
									break;
							case 'n':
								gw.nevermind(); // Don't close the program and clear the exit flag
									break;
							default:
								System.out.println("Please enter y for yes or n for no");
								break;
						
						}
			} //actionPerformed
			} //new ActionListener()
			); //addActionListener
	
	}// play
	


}
