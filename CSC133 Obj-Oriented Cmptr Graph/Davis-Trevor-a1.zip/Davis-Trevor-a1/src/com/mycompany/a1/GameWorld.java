package com.mycompany.a1;
import java.util.Random;
import com.codename1.charts.util.ColorUtil;
import java.util.Vector;
import com.codename1.charts.models.Point;

public class GameWorld {
	private boolean xTrue = false;
	private int clock = 0;
	private int lives = 3;
	Ant ant;
	Random rand = new Random();
	Point location = new Point();
	FoodStation fs;
	Spider spider;
	Flag flag;
	
	Vector<GameObject> vector = new Vector<GameObject>();
	
	// responsible for creating the initial state of the world.
	public void init() {
		
		
		//Food Stations				
		//         fs = new FoodStation(       size,           random location,       color,             capacity); 
		vector.add(fs = new FoodStation(10 + rand.nextInt(40), randomLocation(),ColorUtil.green(255), 1 + rand.nextInt(2)));
		vector.add(fs = new FoodStation(10 + rand.nextInt(40), randomLocation(),ColorUtil.green(255), 1 + rand.nextInt(2)));
	
		//Flags
		// add new instatiations to vector (sequence, x, y)
		vector.add(flag = new Flag(1, new Point(200, 400), ColorUtil.red(255)));
		vector.add(flag = new Flag(2, new Point(200, 800), ColorUtil.red(255)));
		vector.add(flag = new Flag(3, new Point(700, 800), ColorUtil.red(255)));
		vector.add(flag = new Flag(4, new Point(100, 800), ColorUtil.red(255)));
		
		// Spider
		//						Spider(          size,        random location,      color,             heading
		vector.add(spider = new Spider(10 + rand.nextInt(40), randomLocation(), ColorUtil.BLACK, 0 + rand.nextInt(359)));
		vector.add(spider = new Spider(10 + rand.nextInt(40), randomLocation(), ColorUtil.BLACK, 0 + rand.nextInt(359)));

		// Ant
		//                   Ant(      location,           color)
		vector.add(ant = new Ant(new Point(200, 400), ColorUtil.blue(255)));
		
	}

	// accelerate the ant by a small amount
	public void accelerate() {
		for (int i=0; i<vector.size(); i++) {
			if (vector.elementAt(i) instanceof Ant) { 
				Ant antObj = (Ant)vector.elementAt(i); 
				if(antObj.getSpeed() == antObj.getMaximumSpeed()) {
					System.out.println("Cannot accelerate ant beyond maximum speed");
				}// if
				
				else if (antObj.getSpeed() != ant.getMaximumSpeed()) {
					antObj.setSpeed(antObj.getSpeed() + 1);
					System.out.println("Acceleration was applied.");
				}// else if
			}//if	
		}// for loop	
	}// accelerate

	// brake the ant by a small amount
	public void brake() {
		for (int i=0; i<vector.size(); i++) {
			if (vector.elementAt(i) instanceof Ant) { 
				Ant antObj = (Ant)vector.elementAt(i);
				if(antObj.getSpeed() == 0) // if the ant speed is 0
					System.out.println("Cannot brake ant beyond the minimum speed");
				else {
					antObj.setSpeed(antObj.getSpeed() - 1);
					System.out.println("Brake was applied.");
					}// else
				}// 1st if
		}// for loop
	}// brake

	//  change the heading of the ant by 5 degrees to the left
	public void left() {
		for (int i=0; i<vector.size(); i++) {
			if (vector.elementAt(i) instanceof Ant) { 
				Ant antObj = (Ant)vector.elementAt(i);
				antObj.changeHeading(antObj.getHeading()-5);
			}// if statement
		}
		
		System.out.println("left turn was applied.");
	}

	// change the heading of the ant by 5 degrees to the right
	public void right() {
		for (int i=0; i<vector.size(); i++) {
			if (vector.elementAt(i) instanceof Ant) { 
				Ant antObj = (Ant)vector.elementAt(i);
				antObj.changeHeading(antObj.getHeading()+5);
			}// if statement
		}
		
		System.out.println("right turn was applied.");
	}

	// PRETEND that the ant has collided with a food station
	public void foodCollide() {
		 
		// loop through the object to get an instance of FoodStation object
		for (int i=0; i<vector.size(); i++) {
			
			if (vector.elementAt(i) instanceof FoodStation) { 
				FoodStation food = (FoodStation)vector.elementAt(i); 
				food.setColor(ColorUtil.green(150));
				}// if statement
			
			if(vector.elementAt(i) instanceof Ant) {
				Ant antObj = (Ant)vector.elementAt(i);
				FoodStation food = (FoodStation)vector.elementAt(i); 
				antObj.setFoodLevel(antObj.getFoodLevel() + fs.getCapacity()); // increase the food level with the capacity
				food.setCapacity(0);
				}// if statement
			}// for loop
		
		// add a new food station into the program
		vector.add(fs = new FoodStation(10 + rand.nextInt(40), randomLocation(),ColorUtil.green(255), 1 + rand.nextInt(2)));
		System.out.println("Ant has collided with food.");
	}//foodCollide

	// PRETEND that a spider has gotten to the same location and collided with the ant
	public void spiderGotAnt() { 
		// finds the instance of the ant object in the vector list
		for (int i=0; i<vector.size(); i++) {
			if (vector.elementAt(i) instanceof Ant) { 
				Ant antObj = (Ant)vector.elementAt(i); 
				// if you are on your last life
				if(lives == 1) {
					System.out.println("You ran out of lives. The Game is over.");
					System.exit(0);// exit the system
				}
				// if you are not on your last life
				if (lives > 1) {
					antObj.setHealth(antObj.getHealth() - 1); // decreases the current health by 1
					antObj.setColor(antObj.getColor()-50); // lightens the shade of the ant
					lives = lives - 1; // lose a life
					System.out.println("Ant has collided with a spider. Your health went down by one.");
					vector.clear(); // clears all object in the vector list
					init(); // re-initializes the game
				}// else if
			}// 1s if statement
		}// for loop	
	}// spiderGotAnt

	// if 'x' was pressed, set xTrue == true
	public boolean exit() {
		xTrue = true;
		return xTrue;
	}

	// after 'x' was pressed, the user decided not to close the program by pressing 'n'
	public boolean nevermind() {
		xTrue = false; // sets xTure to false
		return xTrue;
	}

	// method only to return the value of xTrue
	public boolean getxTrue() {
		return xTrue;
	}

	// output lines of text on the console describing current game/ant state values
	public void displayState() {
		System.out.println("            Lives: " + lives);
		System.out.println("     Elapsed time: " + clock);
		System.out.println("Last flag reached: " + ant.getLastFlagReached());
		System.out.println("       Food level: " + ant.getFoodLevel());
		System.out.println("     Health level: " + ant.getHealth());
		System.out.println("--The current game/ant state was displayed.--");
	}

	public void flagReached(int flagNumber) {
		// if the new flag is one greater than the last flag that was reached
		// ex) if(2 == 3-1) ant went to next flag......... if(2 == 4-1), the ant skipped flag 3
		if(ant.getLastFlagReached() == flagNumber - 1)
		{
			ant.setLastFlagReached(flagNumber);
			System.out.println("You are now at flag #" + flagNumber);
		}
		
		// if the flag entered is the one they are currently at
		else if(ant.getLastFlagReached() == flagNumber)
			System.out.println("You are currently at this flag");
		
		// if the flag number is less than the last flag reached
		else if(ant.getLastFlagReached() > flagNumber)
			System.out.println("Keep going forward! Your flag will not be updated backwards");
		
		// if the ant tries to skip flags
		else if(ant.getLastFlagReached() < flagNumber - 1)
			System.out.println("You cannot skip flags, please proceed in order.");
			
	}
	
	
	// Spiders update their heading
	// all moveable objects are told to update their positions according to their current heading and speed
	// the ants food level is reduced by the amount indicated by its foodConsumptionRate
	// the elapsed time game clock is incremented by one
	public void ticked() {
		int r;
		for (int i=0; i<vector.size(); i++) {
			if (vector.elementAt(i) instanceof Spider) { 
				Spider sObj = (Spider)vector.elementAt(i);		
				r = 1 + rand.nextInt(10);
				if(r % 2 == 0) { // decide randomly for plus or minus
					 // minus 5 from heading
					sObj.move(sObj.getLocation(), sObj.getHeading() - 5, sObj.getSpeed());
				}
				else {
					 // add 5 to heading
					sObj.move(sObj.getLocation(), sObj.getHeading()+5, sObj.getSpeed());
				}// else
				}
			if(vector.elementAt(i) instanceof Ant) {
				Ant antObj = (Ant)vector.elementAt(i);
				antObj.move(antObj.getLocation(), antObj.getHeading(), antObj.getSpeed());
				
			}
			}
		
		clock = clock +1; // the elapsed time game clock is incremented by one
	}
	
	
	// method to create a random color
	private int randomColor() {
		
		return ColorUtil.rgb(1 + rand.nextInt(244), 1 + rand.nextInt(244),1 + rand.nextInt(244));
	}
	
	// method to create a random point
	private Point randomLocation() {
		Point location;
		location = new Point(rand.nextInt(1000),rand.nextInt(1000));
		
		return  location;
	}

	public void map() {
		for (int i=0; i<vector.size(); i++) {
			if (vector.elementAt(i) instanceof Flag) { 
				Flag flag = (Flag)vector.elementAt(i); 
				System.out.println(flag.toString());
			}
			if (vector.elementAt(i) instanceof Ant) { 
				Ant antObj = (Ant)vector.elementAt(i); 
				System.out.println(antObj.toString());
				}
			if (vector.elementAt(i) instanceof Spider) { 
				Spider spider = (Spider)vector.elementAt(i); 
				System.out.println(spider.toString());
				}
			if (vector.elementAt(i) instanceof FoodStation) { 
				FoodStation food = (FoodStation)vector.elementAt(i); 
				System.out.println(food.toString());
				}
			
			}
		
	}

	


	

}
