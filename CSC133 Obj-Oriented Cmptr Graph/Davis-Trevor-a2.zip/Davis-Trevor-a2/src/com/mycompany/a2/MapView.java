package com.mycompany.a2;

import java.util.Observable;
import java.util.Observer;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Container;
import com.codename1.ui.TextArea;
import com.codename1.ui.layouts.BorderLayout;
import com.codename1.ui.plaf.Border;

public class MapView extends Container implements Observer{
	private TextArea gameText;
	private static int height;
	private static int width;
	private GameWorld gw;
	private GameObjectCollection gameObjects= new GameObjectCollection();
	
	public MapView() {
		this.getAllStyles().setBorder(Border.createLineBorder(10,ColorUtil.rgb(255, 0, 0)));
		this.setLayout(new BorderLayout());
		gameText = new TextArea();
		gameText.setEditable(false);
		gameText.getAllStyles().setBgTransparency(0);
		MapView.height = this.getHeight();
		MapView.width = this.getWidth();
		height = 1000;
		width = 1000;
		this.add(BorderLayout.NORTH, gameText);
		
	}
	
	
	public static int getMapHeight() {
		return height;
	}
	
	public static int getMapWidth() {
		return width;
	}
	
	public void update (Observable o, Object arg) {
		// code here to call the method in GameWorld (Observable) that output the
		// game object information to the console
		gw = (GameWorld) o;
		IIterator theElements = gameObjects.getIterator();	
		String display = "";
		while(theElements.hasNext()){
			display = display + theElements.getNext().toString()+"\n";
		}
		gameText.setText(display);
		revalidate();
		
		}
}
