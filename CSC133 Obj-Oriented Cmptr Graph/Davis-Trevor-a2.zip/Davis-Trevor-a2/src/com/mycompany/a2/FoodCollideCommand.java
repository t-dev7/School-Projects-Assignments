package com.mycompany.a2;

import com.codename1.ui.Command;
import com.codename1.ui.events.ActionEvent;

public class FoodCollideCommand extends Command{
	  private GameWorld gw;
	  private static FoodCollideCommand food;
	
	 private FoodCollideCommand(GameWorld gw)
	    {
	        super("Collide with Food Station");
	        this.gw = gw;
	    }
	 
	 public static FoodCollideCommand getFood(GameWorld gw) {  
			if (food == null)
				food =  new FoodCollideCommand(gw);
			return food;
			}
	 
	 public void actionPerformed(ActionEvent f)
	    {
	        gw.foodCollide();
	    }

}
