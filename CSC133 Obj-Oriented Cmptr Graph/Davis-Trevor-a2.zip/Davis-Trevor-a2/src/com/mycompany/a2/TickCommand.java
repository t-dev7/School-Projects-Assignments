package com.mycompany.a2;

import com.codename1.charts.models.Point;
import com.codename1.ui.Command;
import com.codename1.ui.events.ActionEvent;

public class TickCommand extends Command{
    private GameWorld gw;
    private static TickCommand ticked;
    
    private TickCommand(GameWorld gw)
    {
        super("Tick");
        this.gw = gw;
    }
    
    public static TickCommand getTick(GameWorld gw) {  
		if (ticked == null)
			ticked =  new TickCommand(gw);
		return ticked;
		}
    
    public void actionPerformed(ActionEvent e)
    {
        gw.ticked();
        gw.map();
    }
}
