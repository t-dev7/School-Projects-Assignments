package com.mycompany.a2;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.CheckBox;
import com.codename1.ui.ComboBox;
import com.codename1.ui.Component;
import com.codename1.ui.Button;
import com.codename1.ui.Container;
import com.codename1.ui.Form;
import com.codename1.ui.Label;
import com.codename1.ui.TextField;
import com.codename1.ui.layouts.BoxLayout;
import com.codename1.ui.layouts.FlowLayout;
import com.codename1.ui.layouts.GridLayout;
import com.codename1.ui.Toolbar;
import com.codename1.ui.events.ActionEvent;
import com.codename1.ui.plaf.Border;
import com.codename1.ui.events.ActionListener;
import com.codename1.ui.layouts.BorderLayout;


public class Game extends Form{
	private GameWorld gw;
	private MapView mv;
	private ScoreView sv;
	
	public Game () {
		
		this.setLayout(new BorderLayout());
		gw = new GameWorld(); // Game constructor instantiates a GameWorld
		gw = new GameWorld(); // create Observable GameWorld
		mv = new MapView(); // create an Observer for the map
		sv = new ScoreView(); // create an Observe for the game/ant state data
		gw.addObserver(mv); // register the map observer
		gw.addObserver(sv); // register the score observer
		
		
		this.add(BorderLayout.NORTH,sv);
		// code here to query MapView's width and height and set them as world's
		 // width and height
		this.add(BorderLayout.CENTER,mv);
		
		
		
		// code here to create Command objects for each command,
			menuCommands();
			leftCommands();
			rightCommands();
			bottomCommands();

		
		this.show();
		
		
		gw.init(); // calls a GameWorld method init() to set the initial state of the game
	//	play(); // starts the game by calling a Game method play()
	}
	
	private void menuCommands() {
		Toolbar tb = new Toolbar();
		this.setToolbar(tb);
		tb.setTitle("Walkit Game");
	
		// Sound
		CheckBox chkBoxcmd = new CheckBox();
		chkBoxcmd.getAllStyles().setBgTransparency(255);
		chkBoxcmd.getAllStyles().setBgColor(ColorUtil.LTGRAY);
		SoundCommand snc = new SoundCommand(gw);
		chkBoxcmd.setCommand(snc);
		tb.addComponentToSideMenu(chkBoxcmd);
		
		//Acceleration
		AccelerateCommand acc = AccelerateCommand.getAcc(gw);
		tb.addCommandToSideMenu(acc);
		
		//About
		AboutCommand about = AboutCommand.getAbt();
		tb.addCommandToSideMenu(about);
		
		// Exit
		ExitCommand exit = ExitCommand.getExit();
		tb.addCommandToSideMenu(exit);
		addKeyListener('x',exit);	
//		
//		//Help
		HelpCommand help = HelpCommand.getHelp();
		tb.addCommandToRightBar(help);
//		
	}
	
private void rightCommands() {
	Container rightContainer = new Container(new BoxLayout(BoxLayout.Y_AXIS));
	//setting the back ground color of center container to light gray
	rightContainer.getAllStyles().setBgTransparency(255);
	rightContainer.getAllStyles().setBgColor(ColorUtil.LTGRAY);
	
	// Brake command
	BrakeCommand brake = BrakeCommand.getBrake(gw);
	Button btnBrake = new Button(brake);
	// button styling 
	btnBrake.getAllStyles().setBgTransparency(255);
	btnBrake.getUnselectedStyle().setBgColor(ColorUtil.BLUE);
	btnBrake.getAllStyles().setBorder(Border.createLineBorder(3,ColorUtil.rgb(0, 0, 0)));
	btnBrake.getAllStyles().setFgColor(ColorUtil.rgb(255, 255, 255));
	btnBrake.getAllStyles().setPadding(TOP, 5);
	btnBrake.getAllStyles().setPadding(BOTTOM, 5);
	btnBrake.getAllStyles().setPadding(LEFT, 5);
	btnBrake.setCommand(brake);
	rightContainer.add(btnBrake); // add the flag button to the container
	addKeyListener('b',brake);	
	
	// right command 
	RightCommand right = RightCommand.getRight(gw);
	Button btnRight = new Button(right);
	// button styling
	btnRight.getAllStyles().setBgTransparency(255);
	btnRight.getUnselectedStyle().setBgColor(ColorUtil.BLUE);
	btnRight.getAllStyles().setBorder(Border.createLineBorder(3,ColorUtil.rgb(0, 0, 0)));
	btnRight.getAllStyles().setFgColor(ColorUtil.rgb(255, 255, 255));
	btnRight.getAllStyles().setPadding(TOP, 5);
	btnRight.getAllStyles().setPadding(BOTTOM, 5);
	btnRight.getAllStyles().setPadding(LEFT, 5);
	btnRight.setCommand(right);
	rightContainer.add(btnRight); 
	addKeyListener('r',right);	
	
	rightContainer.getAllStyles().setBorder(Border.createLineBorder(4,
			ColorUtil.BLACK));
			add(BorderLayout.EAST,rightContainer); // put the container in the south
		
		
	}

private void leftCommands() {
	Container leftContainer = new Container(new BoxLayout(BoxLayout.Y_AXIS));
	//setting the back ground color of center container to light gray
	leftContainer.getAllStyles().setBgTransparency(255);
	leftContainer.getAllStyles().setBgColor(ColorUtil.LTGRAY);

	// accelerate command
	AccelerateCommand acc = AccelerateCommand.getAcc(gw);
	Button btnAcc = new Button(acc);
	// button styling
	btnAcc.getAllStyles().setBgTransparency(255);
	btnAcc.getUnselectedStyle().setBgColor(ColorUtil.BLUE);
	btnAcc.getAllStyles().setBorder(Border.createLineBorder(3,ColorUtil.rgb(0, 0, 0)));
	btnAcc.getAllStyles().setFgColor(ColorUtil.rgb(255, 255, 255));
	btnAcc.getAllStyles().setPadding(TOP, 5);
	btnAcc.getAllStyles().setPadding(BOTTOM, 5);
	btnAcc.getAllStyles().setPadding(LEFT, 5);
	btnAcc.setCommand(acc);
	leftContainer.add(btnAcc);
	addKeyListener('a',acc);	
	
	// left command
	LeftCommand left = LeftCommand.getLeft(gw);
	Button btnLeft = new Button(left);
	// button styling
	btnLeft.getAllStyles().setBgTransparency(255);
	btnLeft.getUnselectedStyle().setBgColor(ColorUtil.BLUE);
	btnLeft.getAllStyles().setBorder(Border.createLineBorder(3,ColorUtil.rgb(0, 0, 0)));
	btnLeft.getAllStyles().setFgColor(ColorUtil.rgb(255, 255, 255));
	btnLeft.getAllStyles().setPadding(TOP, 5);
	btnLeft.getAllStyles().setPadding(BOTTOM, 5);
	btnLeft.getAllStyles().setPadding(LEFT, 5);
	btnLeft.setCommand(left);
	// add to container
	leftContainer.add(btnLeft); 
	addKeyListener('l',left);	
	
	leftContainer.getAllStyles().setBorder(Border.createLineBorder(4,
			ColorUtil.BLACK));
			add(BorderLayout.WEST,leftContainer); // put the container in the west
		
	}


	
	
	private void bottomCommands() {
		
		Container bottomContainer = new Container(new BoxLayout(BoxLayout.X_AXIS));
		//setting the back ground color of center container to light gray
		bottomContainer.getAllStyles().setBgTransparency(255);
		bottomContainer.getAllStyles().setBgColor(ColorUtil.LTGRAY);
		
		// Event driven, flag command that is linked to button
		FlagCollideCommand flag = FlagCollideCommand.getFlag(gw);
		Button btnFlag = new Button(flag);
		btnFlag.getAllStyles().setBgTransparency(255);
		btnFlag.getUnselectedStyle().setBgColor(ColorUtil.BLUE);
		btnFlag.getAllStyles().setBorder(Border.createLineBorder(3,ColorUtil.rgb(0, 0, 0)));
		btnFlag.getAllStyles().setFgColor(ColorUtil.rgb(255, 255, 255));
		btnFlag.getAllStyles().setMarginLeft(450);
		btnFlag.getAllStyles().setPadding(TOP, 5);
		btnFlag.getAllStyles().setPadding(BOTTOM, 5);
		btnFlag.getAllStyles().setPadding(LEFT, 5);
		btnFlag.setCommand(flag);
		bottomContainer.add(btnFlag); // add the flag button to the container
		
		
		// Collide with Spider Button
		SpiderCollideCommand spider = SpiderCollideCommand.getSpider(gw);
		Button btnSpider = new Button(spider);
		btnSpider.getAllStyles().setBgTransparency(255);
		btnSpider.getUnselectedStyle().setBgColor(ColorUtil.BLUE);
		btnSpider.getAllStyles().setBorder(Border.createLineBorder(3,ColorUtil.rgb(0, 0, 0)));
		btnSpider.getAllStyles().setFgColor(ColorUtil.rgb(255, 255, 255));
		btnSpider.getAllStyles().setPadding(TOP, 5);
		btnSpider.getAllStyles().setPadding(BOTTOM, 5);
		bottomContainer.add(btnSpider);
		addKeyListener('g',spider);		
		
		// Collide with food Button
		FoodCollideCommand fs = FoodCollideCommand.getFood(gw);
		Button btnFood = new Button(fs);
		btnFood.getAllStyles().setBgTransparency(255);
		btnFood.getUnselectedStyle().setBgColor(ColorUtil.BLUE);
		btnFood.getAllStyles().setBorder(Border.createLineBorder(3,ColorUtil.rgb(0, 0, 0)));
		btnFood.getAllStyles().setFgColor(ColorUtil.rgb(255, 255, 255));
		btnFood.getAllStyles().setPadding(TOP, 5);
		btnFood.getAllStyles().setPadding(BOTTOM, 5);
		bottomContainer.add(btnFood);
		addKeyListener('f',fs);
		
		// tick command
		TickCommand tick = TickCommand.getTick(gw);
		Button btnTick = new Button(tick);
		btnTick.getAllStyles().setBgTransparency(255);
		btnTick.getUnselectedStyle().setBgColor(ColorUtil.BLUE);
		btnTick.getAllStyles().setBorder(Border.createLineBorder(3,ColorUtil.rgb(0, 0, 0)));
		btnTick.getAllStyles().setFgColor(ColorUtil.rgb(255, 255, 255));
		btnTick.getAllStyles().setPadding(TOP, 5);
		btnTick.getAllStyles().setPadding(BOTTOM, 5);
		btnTick.setCommand(tick);
		bottomContainer.add(btnTick);
		addKeyListener('t',tick);
		
		
		//setting the border Color
		bottomContainer.getAllStyles().setBorder(Border.createLineBorder(4,
		ColorUtil.BLACK));
		add(BorderLayout.SOUTH,bottomContainer); // put the container in the south

	
	}
	
}