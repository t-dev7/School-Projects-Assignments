package com.mycompany.a2;

import com.codename1.ui.Command;
import com.codename1.ui.events.ActionEvent;

public class SpiderCollideCommand extends Command{
	private GameWorld gw;
	private static SpiderCollideCommand spider;
	
    private SpiderCollideCommand(GameWorld gw)
    {
        super("Collide with Spider");
        this.gw = gw;
    }

    public static SpiderCollideCommand getSpider(GameWorld gw) {  
		if (spider == null)
			spider =  new SpiderCollideCommand(gw);
		return spider;
		}
    
    public void actionPerformed(ActionEvent g)
    {
        gw.spiderGotAnt();
    }
}
