package com.mycompany.a2;
import com.codename1.charts.models.Point;
import com.codename1.charts.util.ColorUtil;

public class Ant extends Moveable implements ISteerable{
	private int maximumSpeed;
	private int foodLevel;
	private int foodConsumptionRate;
	private int healthLevel;
	private int lastFlagReached; 
	private static Ant theAnt;
	
	Point location;
	
	private Ant(Point location, int color) {
		
		super(10, location, color, 0, 5);
		healthLevel = 10;
		maximumSpeed = 10;
		foodLevel = 10;
		foodConsumptionRate = 1;
		lastFlagReached = 1;
	}
	
	public static Ant getAnt(Point location, int color) {  
		if (theAnt == null)
			theAnt =  new Ant(location, color);
		return theAnt;
		}
	

	
	// method to update new location
	public void move(Point oldLocation, double heading, int speed) {
		float deltaX;float deltaY;float oldX;float oldY;float newX;float newY;	
		
		deltaX = (float) (Math.cos(Math.toRadians(90-heading))*speed);
		deltaY = (float) (Math.sin(Math.toRadians(90-heading))*speed);
		
		oldX = oldLocation.getX();
		oldY = oldLocation.getY();
		
		newX = deltaX + oldX;
		newY = deltaY + oldY;
		
		location = new Point(Math.round(newX*10)/10, Math.round(newY*10)/10);
		
	super.move(location);
	}
	
	// return health level
	public int getHealth() {
		return healthLevel;
	}
	
	
	// method to set new health
	public void setHealth(int newHealth) {
		healthLevel = newHealth;
	}
	
	// return maximum speed
	public int getMaximumSpeed() {
		return maximumSpeed;
	}
	
	// set new maximum speed
	public void setMaximumSpeed(int newMax) {
		maximumSpeed = newMax;
	}
	
	
	// gets food level
	public int getFoodLevel() {
		return foodLevel;
	}
	
	// sets food level to new value
	public void setFoodLevel(int newFood) {
		foodLevel = newFood;
	}
	
	// returns the last flag reached
	public int getLastFlagReached() {
		return lastFlagReached;
	}
	
	// updates the last flag reached
	public void setLastFlagReached(int newLastFlag) {
		lastFlagReached = newLastFlag;
	}
	
	// gets/returns the food consumption rate
	public int getFoodConsumptionRate() {
		return foodConsumptionRate;
	}
	
	// method to set color from the subclasses
		public void setColor(int color) {
			super.setColor(color);
		}
	
	//
	//public void setFoodConsumptionRate(int newFoodRate) {
	//	foodConsumptionRate = newFoodRate;
	//}
	
	// overloaded method to set a new location
	public void setLocation(Point location) {
		 super.setLocation(location);
	 }
	
	public void changeHeading(double heading) {
		super.setHeading(heading);
	}
	
	// empty method
	public void setHeading(double heading) {
				
	}
	
	public String toString() {
		String colorDesc = "color=[" + ColorUtil.red(super.getColor())  + ", "
				 + ColorUtil.green(super.getColor()) + ", "
				 + ColorUtil.blue(super.getColor()) + "] ";

		String sLocation = "loc=" + super.getLocation().getX() + ", "
			  + super.getLocation().getY() + " ";

		String sSize = "size=" + super.getSize() + " ";
		
		String sHeading = "heading=" + super.getHeading() + " ";
		
		String sSpeed = "speed=" + super.getSpeed()+ " ";
		
		String sMaxSpeed = "maxSpeed=" + maximumSpeed + " ";
		
		String sFoodRate = "foodConsumptionRate=" + foodConsumptionRate + " ";
		
		return "Ant: " + sLocation + colorDesc + sHeading + sSpeed + sSize + sMaxSpeed + sFoodRate;
	}


}