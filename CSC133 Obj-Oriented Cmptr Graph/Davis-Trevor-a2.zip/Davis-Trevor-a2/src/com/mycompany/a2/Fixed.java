package com.mycompany.a2;

import com.codename1.charts.models.Point;
import com.codename1.charts.util.ColorUtil;

public abstract class Fixed extends GameObject{
	
	public Fixed(int size, Point location, int color) {
		super(size, location, color);
	}
	

	public void setColor(int color) {
	 super.setColor(color);
	}

 	//empty method
	public void setLocation(Point location) {
		 
	 }
 
}