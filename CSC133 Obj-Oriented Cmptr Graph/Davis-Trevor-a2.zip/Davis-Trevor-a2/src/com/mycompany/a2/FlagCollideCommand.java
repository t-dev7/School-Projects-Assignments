package com.mycompany.a2;

import com.codename1.ui.Command;
import com.codename1.ui.Dialog;
import com.codename1.ui.TextField;
import com.codename1.ui.events.ActionEvent;

public class FlagCollideCommand extends Command{
	   private GameWorld gw;
	   private static FlagCollideCommand flag;
	   
	    private FlagCollideCommand(GameWorld gw)
	    {
	        super("Collide with Flag");
	        this.gw = gw;
	    }
	    
	    public static FlagCollideCommand getFlag(GameWorld gw) {  
			if (flag == null)
				flag =  new FlagCollideCommand(gw);
			return flag;
			}
	    
	    
	  
	    public void actionPerformed(ActionEvent e)
	    {   
	    	// create dialog box to get user input for flag 
	    	Command cOk = new Command("Ok");
	    	TextField myTF = new TextField();
	        Dialog.show("Enter flag number: ", myTF, cOk);
	        String text = myTF.getText().toString();
	        try {
	        	int temp = Integer.parseInt(text);
	          if (temp > 0 && temp < 10)	// check for number 1 - 10
	          {
	          	gw.flagReached(temp);	// call gameworld and pass the flag number to it
	          }
	          else {
	        	String info = "Please enter again number between 1 - 9";
	        	Dialog.show("Error",info,"Ok",null);
	          	System.out.println("Please enter again number between 1 - 9");
	          }
	        }catch(NumberFormatException e1) {
	        	 String info = "Please enter an acceptable input";
	             Dialog.show("Error",info,"Ok",null);
	        } 
	    }
}
